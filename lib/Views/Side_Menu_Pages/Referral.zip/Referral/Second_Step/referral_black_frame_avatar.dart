import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:zayroexchange/Utility/Colors/custom_theme_change.dart';
import 'package:zayroexchange/Utility/Images/custom_theme_change.dart';
import 'package:zayroexchange/Utility/custom_text.dart';
import 'package:zayroexchange/Views/Side_Menu_Pages/Referral/Animation_pages/referral_badges.dart';
import 'package:zayroexchange/Views/Side_Menu_Pages/Referral/referral_controller.dart';
import 'package:zayroexchange/l10n/app_localizations.dart';

class ReferralBlackPremiumSliderCard extends StatefulWidget {
  final ReferralController controller;

  const ReferralBlackPremiumSliderCard({super.key, required this.controller});

  @override
  State<ReferralBlackPremiumSliderCard> createState() =>
      _ReferralBlackPremiumSliderCardState();
}

class _ReferralBlackPremiumSliderCardState
    extends State<ReferralBlackPremiumSliderCard> {
  bool isOpen = true;

  void _toggle() {
    setState(() {
      isOpen = !isOpen;
    });
  }

  @override
  Widget build(BuildContext context) {
    final int current = widget.controller.samuraiFragments;
    final int total = 5;
    return Container(
      padding: EdgeInsets.all(15.sp),
      decoration: BoxDecoration(
        color: ThemeTextFormFillColor.getTextFormFillColor(context),
        borderRadius: BorderRadius.circular(15.sp),
        border: Border.all(
          color: ThemeOutLineColor.getOutLineColor(context),
          width: 5.sp,
        ),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: _toggle,
            child: Row(
              children: [
                Expanded(
                  child: CustomText(
                    label:  AppLocalizations.of(context)!.legendaryBlackRobotAvatarFrame,
                    fontSize: 15.5.sp,
                    labelFontWeight: FontWeight.w600,
                    fontColour: ThemeTextColor.getTextColor(context),
                  ),
                ),
                AnimatedRotation(
                  turns: isOpen ? 0.0 : 0.5,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(
                    Icons.keyboard_arrow_up,
                    size: 22.sp,
                    color: ThemeTextOneColor.getTextOneColor(context),
                  ),
                ),
              ],
            ),
          ),
          AnimatedCrossFade(
            crossFadeState: isOpen
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            duration: const Duration(milliseconds: 220),
            firstChild: Column(
              children: [
                SizedBox(height: 12.sp),
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        flex: 2,
                        child: _InfoCard(
                          title:  AppLocalizations.of(context)!.blackFragments,
                          badge: "$current/$total",
                          showCheck: false,
                          iconPath: AppThemeIcons.referralBlackCoin(context),
                        ),
                      ),
                      SizedBox(width: 10.sp),
                      Expanded(
                        flex: 3,
                        child: _InfoCard(
                          title:
                              "$current ${AppLocalizations.of(context)!.legendaryBlackAvatarFrame}",
                          description:
                              "${AppLocalizations.of(context)!.collect} "
                              "$total ${AppLocalizations.of(context)!.blackFragmentsAchieve}\n"
                              "${AppLocalizations.of(context)!.blackFragmentsAchieveSubTwo}",
                          showCheck: current == 5 ? true : false,
                          iconPath: AppThemeIcons.referralBlackFrame(context),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12.sp),
                BlackPremiumStepSlider(current: current, total: total),
              ],
            ),
            secondChild: const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String? badge;
  final bool showCheck;
  final String? description;
  final String iconPath;

  const _InfoCard({
    required this.title,
    required this.iconPath,
    this.badge,
    this.showCheck = false,
    this.description,
  });

  @override
  Widget build(BuildContext context) {
    final Widget badgeWidget = badge != null
        ? ReferralCountBadge(label: badge!, size: 22.sp, fontSize: 12.sp)
        : (showCheck
              ? Align(
                  alignment: Alignment.topRight,
                  child: ReferralTickBadge(size: 20.sp),
                )
              : const SizedBox.shrink());
    final Alignment badgeAlignment = showCheck
        ? Alignment.topRight
        : Alignment.topLeft;

    return Container(
      constraints: BoxConstraints(minHeight: 20.h),
      padding: EdgeInsets.all(10.sp),
      decoration: BoxDecoration(
        color: ThemeOutLineColor.getOutLineColor(context),
        borderRadius: BorderRadius.circular(16.sp),
      ),
      child: Column(
        children: [
          Align(alignment: badgeAlignment, child: badgeWidget),

          /// ICON
          SvgPicture.asset(iconPath, height: 30.sp, width: 30.sp),

          SizedBox(height: 20.sp),
          CustomText(
            label: title,
            align: TextAlign.center,
            labelFontWeight: FontWeight.w600,
          ),
          SizedBox(height: 10.sp),

          /// DESCRIPTION
          if (description != null)
            CustomText(
              label: description!,
              align: TextAlign.center,
              lineSpacing: 5.sp,
              fontSize: 12.5.sp,
              fontColour: ThemeTextOneColor.getTextOneColor(context),
            ),
        ],
      ),
    );
  }
}

class BlackPremiumStepSlider extends StatefulWidget {
  final int current;
  final int total;

  const BlackPremiumStepSlider({
    super.key,
    required this.current,
    required this.total,
  });

  @override
  State<BlackPremiumStepSlider> createState() => _BlackPremiumStepSliderState();
}

class _BlackPremiumStepSliderState extends State<BlackPremiumStepSlider> {
  @override
  Widget build(BuildContext context) {
    final double current = widget.current.clamp(0, widget.total).toDouble();
    final double total = widget.total.toDouble();
    final double progress = total == 0 ? 0 : current / total;
    return Column(
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final double width = constraints.maxWidth;
            return SizedBox(
              height: 28,
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 12,
                    child: Container(
                      height: 6,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0F0F17),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 12,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      width: width * progress,
                      height: 6,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF007FFF),
                            Color(0xFF623EF8),
                            Color(0xFFBF00FF),
                          ],
                          stops: [0.0, 0.35, 1.0],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  ...List.generate(widget.total + 1, (index) {
                    final double percent = widget.total == 0
                        ? 0
                        : index / widget.total;
                    return Positioned(
                      left: width * percent - 0.75,
                      top: 8,
                      child: Container(
                        width: 1.5,
                        height: 14,
                        color: const Color(0xFF2E2E3A),
                      ),
                    );
                  }),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "${widget.current}/${widget.total}",
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
