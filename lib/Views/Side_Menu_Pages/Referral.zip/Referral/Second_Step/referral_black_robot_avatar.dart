import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:zayroexchange/Utility/Colors/custom_theme_change.dart';
import 'package:zayroexchange/Utility/Images/custom_theme_change.dart';
import 'package:zayroexchange/Utility/custom_text.dart';
import 'package:zayroexchange/Views/Side_Menu_Pages/Referral/Animation_pages/referral_badges.dart';
import 'package:zayroexchange/Views/Side_Menu_Pages/Referral/referral_controller.dart';
import 'package:zayroexchange/l10n/app_localizations.dart';
import 'package:zayroexchange/l10n/app_localizations_en.dart';

class ReferralBlackRobotSliderCard extends StatefulWidget {
  final ReferralController controller;
  const ReferralBlackRobotSliderCard({super.key, required this.controller});

  @override
  State<ReferralBlackRobotSliderCard> createState() =>
      _ReferralBlackRobotSliderCardState();
}

class _ReferralBlackRobotSliderCardState
    extends State<ReferralBlackRobotSliderCard> {
  bool isOpen = true;

  void _toggle() {
    setState(() {
      isOpen = !isOpen;
    });
  }

  @override
  Widget build(BuildContext context) {
    final int current = widget.controller.legendaryFragments;
    final int count = widget.controller.fullResetCount;
    final int total = 20;
    return Container(
      padding: EdgeInsets.all(15.sp),
      decoration: BoxDecoration(
        color: ThemeTextFormFillColor.getTextFormFillColor(context),
        borderRadius: BorderRadius.circular(15.sp),
        border: Border.all(
          color: ThemeOutLineColor.getOutLineColor(context),
          width: 5.sp,
        ),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: _toggle,
            child: Row(
              children: [
                Expanded(
                  child: CustomText(
                    label: AppLocalizations.of(
                      context,
                    )!.legendaryBlackRobotAvatar,
                    fontSize: 15.5.sp,
                    labelFontWeight: FontWeight.w600,
                    fontColour: ThemeTextColor.getTextColor(context),
                  ),
                ),
                AnimatedRotation(
                  turns: isOpen ? 0.0 : 0.5,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(
                    Icons.keyboard_arrow_up,
                    size: 22.sp,
                    color: ThemeTextOneColor.getTextOneColor(context),
                  ),
                ),
              ],
            ),
          ),
          AnimatedCrossFade(
            crossFadeState: isOpen
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            duration: const Duration(milliseconds: 220),
            firstChild: Column(
              children: [
                SizedBox(height: 12.sp),
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        flex: 2,
                        child: _InfoCard(
                          title: AppLocalizations.of(context)!.blackFragments,
                          badge: "$current/$total",
                          iconPath: AppThemeIcons.referralBlackCoin(context),
                        ),
                      ),
                      SizedBox(width: 10.sp),
                      Expanded(
                        flex: 3,
                        child: _InfoCard(
                          title: "$current ${AppLocalizations.of(context)!.legendaryBlackRobotAvatar}",
                          description:
                              "${AppLocalizations.of(context)!.collect} "
                              " $total ${AppLocalizations.of(context)!.blackFragmentsAchieve}\n"
                              "${AppLocalizations.of(context)!.inviteRobotAvatarFragments}\n"
                              "$current ${AppLocalizations.of(context)!.blackSamuraiRobotAvatar}",
                          count: count,
                          iconPath: AppThemeIcons.referralBlackRobot(context),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12.sp),
                BlackRobotStepSlider(current: current, total: total),
              ],
            ),
            secondChild: const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String? badge;
  final int? count;
  final String? description;
  final String iconPath;

  const _InfoCard({
    required this.title,
    required this.iconPath,
    this.badge,
    this.count,
    this.description,
  });

  @override
  Widget build(BuildContext context) {
    final Widget badgeWidget = badge != null
        ? ReferralCountBadge(label: badge!, size: 22.sp, fontSize: 12.sp)
        : (count != null
              ? ReferralCountBadge(
                  label: count.toString(),
                  size: 20.sp,
                  fontSize: 14.sp,
                )
              : const SizedBox.shrink());
    final Alignment badgeAlignment = count != null
        ? Alignment.topRight
        : Alignment.topLeft;
    final bool showGlow = iconPath == AppThemeIcons.referralBlackRobot(context);
    final Widget iconWidget = showGlow
        ? Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 36.sp,
                height: 36.sp,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      Color(0x887A3CFF),
                      Color(0x336A2CFF),
                      Color(0x006A2CFF),
                    ],
                    stops: [0.0, 0.55, 1.0],
                  ),
                ),
              ),
              SvgPicture.asset(iconPath, height: 32.sp, width: 32.sp),
            ],
          )
        : SvgPicture.asset(iconPath, height: 30.sp, width: 30.sp);

    return Container(
      constraints: BoxConstraints(minHeight: 20.h),
      padding: EdgeInsets.all(10.sp),
      decoration: BoxDecoration(
        color: ThemeOutLineColor.getOutLineColor(context),
        borderRadius: BorderRadius.circular(16.sp),
      ),
      child: Column(
        children: [
          Align(alignment: badgeAlignment, child: badgeWidget),

          /// ICON
          iconWidget,

          SizedBox(height: 15.sp),
          CustomText(
            label: title,
            align: TextAlign.center,
            labelFontWeight: FontWeight.w600,
          ),
          SizedBox(height: 10.sp),

          /// DESCRIPTION
          if (description != null)
            CustomText(
              label: description!,
              align: TextAlign.center,
              lineSpacing: 5.sp,
              fontSize: 12.5.sp,
              fontColour: ThemeTextOneColor.getTextOneColor(context),
            ),
        ],
      ),
    );
  }
}

class BlackRobotStepSlider extends StatefulWidget {
  final int current;
  final int total;

  const BlackRobotStepSlider({
    super.key,
    required this.current,
    required this.total,
  });

  @override
  State<BlackRobotStepSlider> createState() => _BlackRobotStepSliderState();
}

class _BlackRobotStepSliderState extends State<BlackRobotStepSlider> {
  @override
  Widget build(BuildContext context) {
    final double current = widget.current.clamp(0, widget.total).toDouble();
    final double total = widget.total.toDouble();
    final double progress = total == 0 ? 0 : current / total;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "${widget.current}/${widget.total}",
          style: TextStyle(
            color: Colors.white,
            fontSize: 12.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 6.sp),
        LayoutBuilder(
          builder: (context, constraints) {
            final double width = constraints.maxWidth;
            return SizedBox(
              height: 26,
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 10,
                    child: Container(
                      height: 7,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0F0F17),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 10,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      width: width * progress,
                      height: 7,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF007FFF),
                            Color(0xFF623EF8),
                            Color(0xFFBF00FF),
                          ],
                          stops: [0.0, 0.35, 1.0],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  ...List.generate(5, (index) {
                    final int step = index * (widget.total ~/ 4);
                    final double percent = widget.total == 0
                        ? 0
                        : step / widget.total;
                    return Positioned(
                      left: width * percent - 0.75,
                      top: 7,
                      child: Container(
                        width: 1.5,
                        height: 16,
                        color: const Color(0xFF2E2E3A),
                      ),
                    );
                  }),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
